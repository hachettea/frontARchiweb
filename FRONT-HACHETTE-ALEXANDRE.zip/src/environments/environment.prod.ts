export const environment = {
  production: true,
  host: 'http://pedago.univ-avignon.fr:3057',
};
