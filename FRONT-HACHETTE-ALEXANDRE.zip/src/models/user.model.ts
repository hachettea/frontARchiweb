export interface UserModel {
  id?: number;
  identifiant: string;
  motpasse: string;
}
